package io.nuls.core.rpc.util;

public class TimeContainer {
    public static long t1 = 0L;
    public static long t2 = 0L;
    public static long t3 = 0L;
    public static long t4 = 0L;
    public static long t5 = 0L;
}
