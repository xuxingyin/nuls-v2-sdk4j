package io.nuls.core.core.config;

/**
 * @Author: zhoulijun
 * @Time: 2019-03-13 21:01
 * @Description: 功能描述
 */
public class NcfModuleConfigParser extends IniModuleConfigParser {


    @Override
    public String fileSuffix() {
        return "ncf";
    }
}
