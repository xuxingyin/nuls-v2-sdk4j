package io.nuls.core.basic;

public interface VersionChangeInvoker {

    void process(int chainId);

}
