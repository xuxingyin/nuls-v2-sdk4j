package io.nuls.v2.model.dto;

import io.nuls.core.rpc.model.ApiModel;
import io.nuls.core.rpc.model.ApiModelProperty;

import java.math.BigInteger;

@ApiModel
public class CrossTransferForm {

    @ApiModelProperty(description = "转账地址")
    private String address;
    @ApiModelProperty(description = "接收者地址")
    private String toAddress;
    @ApiModelProperty(description = "密码")
    private String password;
    @ApiModelProperty(description = "资产chainId")
    private int assetChainId;
    @ApiModelProperty(description = "资产Id")
    private int assetId;
    @ApiModelProperty(description = "转账金额")
    private BigInteger amount;
    @ApiModelProperty(description = "交易备注")
    private String remark;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getToAddress() {
        return toAddress;
    }

    public void setToAddress(String toAddress) {
        this.toAddress = toAddress;
    }

    public BigInteger getAmount() {
        return amount;
    }

    public void setAmount(BigInteger amount) {
        this.amount = amount;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getAssetChainId() {
        return assetChainId;
    }

    public void setAssetChainId(int assetChainId) {
        this.assetChainId = assetChainId;
    }

    public int getAssetId() {
        return assetId;
    }

    public void setAssetId(int assetId) {
        this.assetId = assetId;
    }
}
